name(lambda_abstractions).
title('Lambda abstractions').
version('0.1.1').
keywords([lambda]).
author('Mauro DiNuzzo', 'mauro.dinuzzo@prologserverpages.com').
download('https://github.com/maurodinuzzo/prolog-lambda-expressions/raw/master/lambda_abstractions-*.zip').
