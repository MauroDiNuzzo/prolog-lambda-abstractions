name(lambdas).
title('Lambda expressions').
version('0.1.1').
keywords([lambda, hiord, meta]).
author('Mauro DiNuzzo', 'mauro.dinuzzo@prologserverpages.com').
download('https://github.com/maurodinuzzo/prolog-lambda-expressions/raw/master/lambda_expressions-*.zip').
